# ARCHITECTURE_MAP.md

## Purpose
This file is a low-token navigation map for agents and humans.
Use it to answer: **where should I look first for this task?**

It is intentionally smaller and more operational than `ARCHITECTURE.md`.

---

## Current Repo State
- The repo is currently greenfield.
- The root docs are the active control plane.
- Implementation modules are not yet established.
- Changes should stay proportional to proven workflow value.
- The tensor layer exists as an optional adaptive behavior subsystem, not yet as a large runtime framework.

---

## Canonical Files and Jobs
- `README.md` — orientation, purpose, current state, next steps
- `AGENT.md` — behavior contract for AI contributors
- `TEAM_MEMORY.md` — durable decisions, invariants, open questions
- `ARCHITECTURE.md` — long-term structural intent
- `docs/AGENT_EVOLUTION_WEIGHTS.md` — adaptive tensor behavior model
- `schemas/agent_tensor_state.schema.json` — validation contract for tensor save states
- `examples/agent_tensor_state.example.json` — example tensor state
- `state/active_agent_tensor_state.json` — current active tensor state
- `scripts/evolve_agent_state.py` — state transition and mutation utility

---

## Task-to-File Routing
- **mission / scope / repo purpose**
  - read: `README.md`, `TEAM_MEMORY.md`
- **agent behavior / escalation / checklist shaping**
  - read: `AGENT.md`
  - if tensor behavior is relevant, also read: `docs/AGENT_EVOLUTION_WEIGHTS.md`
- **system structure / module boundaries**
  - read: `ARCHITECTURE.md`
- **durable decisions / unresolved assumptions**
  - read: `TEAM_MEMORY.md`
- **tensor validation / state format**
  - read: `schemas/agent_tensor_state.schema.json`
  - inspect: `examples/agent_tensor_state.example.json`
- **tensor mutation / inheritance implementation**
  - read: `scripts/evolve_agent_state.py`
  - inspect: `state/active_agent_tensor_state.json`

---

## Context Loading Rules
- Start with only 1–2 root docs plus the smallest directly relevant artifact.
- Do not read all root docs unless the task genuinely spans behavior, memory, and structure.
- Prefer the smallest relevant file set over broad repo scans.
- When changing tensor behavior, read the schema and active/example state before editing prose docs.
- Record durable decisions only when architecture, interfaces, assumptions, or workflow changed.

---

## Current Unresolved Anchors
- first concrete product workflow is not yet chosen
- initial runtime stack is not yet chosen
- canonical domain entities are not yet frozen
- tensor layer exists, but task-specific weighting policies may still evolve
